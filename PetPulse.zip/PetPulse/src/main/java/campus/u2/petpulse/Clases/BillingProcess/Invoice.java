package campus.u2.petpulse.Clases.BillingProcess;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Invoice {

    private Integer CUFE;
    private LocalDate dateInvoice;
    private Boolean state;
    private Integer idOwner;
    private List<ProductsInvoice> productsInvoices; 
    private List<ServiceInvoice> servicesInvoices; 
    private Double total; 

    public Invoice() {
    }

    public Invoice(Integer CUFE, Boolean state, Integer idOwner, Double total) {
        this.CUFE = CUFE;
        this.state = state;
        this.idOwner = idOwner;
        this.total = total;
    }

    public Invoice(Integer idOwner) {
        this.dateInvoice = LocalDate.now();
        this.state = false;
        this.idOwner = idOwner;
        this.productsInvoices = new ArrayList<>();
        this.servicesInvoices = new ArrayList<>();
        
    }
    
    

    public Invoice(Integer CUFE, Integer idOwner) {
        this.CUFE = CUFE;
        this.dateInvoice = LocalDate.now();
        this.state = false;
        this.idOwner = idOwner;
        this.productsInvoices = new ArrayList<>();
        this.servicesInvoices = new ArrayList<>();
        
    }

    public Invoice(Integer CUFE, Boolean state, Integer idOwner) {
        this.CUFE = CUFE;
        this.dateInvoice = LocalDate.now();
        this.state = state;
        this.idOwner = idOwner;
        this.productsInvoices = new ArrayList<>();
        this.servicesInvoices = new ArrayList<>();
        
    }

    public Integer getCUFE() {
        return CUFE;
    }

    public void setCUFE(Integer CUFE) {
        this.CUFE = CUFE;
    }

    public LocalDate getDateInvoice() {
        return dateInvoice;
    }

    public void setDateInvoice(LocalDate dateInvoice) {
        this.dateInvoice = dateInvoice;
    }

    public Boolean getState() {
        return state;
    }

    public void setState(Boolean state) {
        this.state = state;
    }

    public Integer getIdOwner() {
        return idOwner;
    }

    public void setIdOwner(Integer idOwner) {
        this.idOwner = idOwner;
    }

    public List<ProductsInvoice> getProductsInvoices() {
        return productsInvoices;
    }

    public void setProductsInvoices(List<ProductsInvoice> productsInvoices) {
        this.productsInvoices = productsInvoices;
    }

    public List<ServiceInvoice> getServicesInvoices() {
        return servicesInvoices;
    }

    public void setServicesInvoices(List<ServiceInvoice> servicesInvoices) {
        this.servicesInvoices = servicesInvoices;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    @Override
    public String toString() {
        return "Invoice{" +
                "CUFE=" + CUFE +
                ", dateInvoice=" + dateInvoice +
                ", state=" + state +
                ", idOwner=" + idOwner +
                ", productsInvoices=" + productsInvoices +
                ", servicesInvoices=" + servicesInvoices +
                ", total=" + total +
                '}';
    }
}
