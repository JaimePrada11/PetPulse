package campus.u2.petpulse.Clases.BillingProcess;

public class ProductsInvoice {
    private int CUFE;
    private int ID_Product;
    private int quantity;

    public ProductsInvoice() {
    }

    public ProductsInvoice(int CUFE, int ID_Product, int quantity) {
        this.CUFE = CUFE;
        this.ID_Product = ID_Product;
        this.quantity = quantity;
    }

    // Getters y setters

    public int getCUFE() {
        return CUFE;
    }

    public void setCUFE(int CUFE) {
        this.CUFE = CUFE;
    }

    public int getID_Product() {
        return ID_Product;
    }

    public void setID_Product(int ID_Product) {
        this.ID_Product = ID_Product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "ProductsInvoice{" +
                "CUFE=" + CUFE +
                ", ID_Product=" + ID_Product +
                ", quantity=" + quantity +
                '}';
    }
}
