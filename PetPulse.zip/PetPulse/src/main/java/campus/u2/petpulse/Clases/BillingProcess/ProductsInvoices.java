
package campus.u2.petpulse.Clases.BillingProcess;


public class ProductsInvoices {

    private Integer ID_Product;
    private Integer idinvoice;
    private Integer Quantity;
    private Double total;


    public ProductsInvoices() {
        this.total = 0.0;
    }

    public ProductsInvoices(Integer idinvoice, Integer Quantity, Double total) {
        this.idinvoice = idinvoice;
        this.Quantity = Quantity;
        this.total = total;
    }

    
    public ProductsInvoices(Integer ID_Product, Integer idinvoice, Integer Quantity, Double total) {
        this.ID_Product = ID_Product;
        this.idinvoice = idinvoice;
        this.Quantity = Quantity;
        this.total = total;
    }

    // Getters and setters
    public Integer getID_Product() {
        return ID_Product;
    }

    public void setID_Product(Integer ID_Product) {
        this.ID_Product = ID_Product;
    }

    public Integer getCUFE() {
        return idinvoice;
    }

    public void setCUFE(Integer idinvoice) {
        this.idinvoice = idinvoice;
    }

    public Integer getQuantity() {
        return Quantity;
    }

    public void setQuantity(Integer Quantity) {
        this.Quantity = Quantity;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    // Method to calculate total based on unit price
    public void calculateTotal(Double unitPrice) {
        if (unitPrice != null && Quantity != null) {
            this.total = unitPrice * Quantity;
        } else {
            this.total = 0.0;
        }
    }

    @Override
    public String toString() {
        return "ProductsInvoices{" +
                "ID_Product=" + ID_Product +
                ", idinvoice=" + idinvoice +
                ", Quantity=" + Quantity +
                ", total=" + total +
                '}';
    }
}
