package campus.u2.petpulse.Clases.BillingProcess;

public class ServiceInvoice {
    private int CUFE;
    private int idService;
    private int idEmployee;
    private int idPet;
    private double performance;
    private String observations;

    public ServiceInvoice() {
    }

    public ServiceInvoice(int CUFE, int idService, int idEmployee, int idPet, double performance, String observations) {
        this.CUFE = CUFE;
        this.idService = idService;
        this.idEmployee = idEmployee;
        this.idPet = idPet;
        this.performance = performance;
        this.observations = observations;
    }

    public int getCUFE() {
        return CUFE;
    }

    public void setCUFE(int CUFE) {
        this.CUFE = CUFE;
    }

    public int getIdService() {
        return idService;
    }

    public void setIdService(int idService) {
        this.idService = idService;
    }

    public int getIdEmployee() {
        return idEmployee;
    }

    public void setIdEmployee(int idEmployee) {
        this.idEmployee = idEmployee;
    }

    public int getIdPet() {
        return idPet;
    }

    public void setIdPet(int idPet) {
        this.idPet = idPet;
    }

    public double getPerformance() {
        return performance;
    }

    public void setPerformance(double performance) {
        this.performance = performance;
    }

    public String getObservations() {
        return observations;
    }

    public void setObservations(String observations) {
        this.observations = observations;
    }

    @Override
    public String toString() {
        return "ServiceInvoice{" +
                "CUFE=" + CUFE +
                ", idService=" + idService +
                ", idEmployee=" + idEmployee +
                ", idPet=" + idPet +
                ", performance=" + performance +
                ", observations='" + observations + '\'' +
                '}';
    }
}
