package campus.u2.petpulse.Controlador.AppoinmentsControllers;

import campus.u2.petpulse.Clases.Animals.Animal;
import campus.u2.petpulse.Clases.Appointments.Appointment;
import campus.u2.petpulse.Clases.Appointments.State;
import campus.u2.petpulse.Controlador.Users.PetControlador;
import campus.u2.petpulse.Persistencia.CRUD;
import campus.u2.petpulse.Persistencia.ConexionDB;
import java.sql.Connection;

import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class AppointmentController {

    public static boolean registerAppointment(LocalDateTime dateAppointment, String reason, State state, Animal mascota) throws SQLException {
        CRUD.setConnection(ConexionDB.getConexion());

        Appointment appointment = new Appointment(dateAppointment, reason, state, mascota);

        String query = "INSERT INTO Appointments (DateAppointment, Reason, ID_Pet, ID_State) VALUES ('"
                + appointment.getDateAppointment() + "', '" + appointment.getReason() + "', " + appointment.getMascota().getIdPet() + ", "
                + appointment.getState().getIdState() + ");";

        return CRUD.executeCommit(query);
    }

    public static boolean updateAppointment(int id, LocalDateTime dateAppointment, String reason, State state) throws SQLException {
        CRUD.setConnection(ConexionDB.getConexion());

        // Formatear la fecha para que sea compatible con MySQL
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDate = dateAppointment.format(formatter);

        // Construir la consulta SQL con las comillas correctas para reason
        String query = "UPDATE Appointments SET DateAppointment='" + formattedDate + "', Reason='"
                + reason + "', ID_State=" + state.getIdState()
                + " WHERE ID_Appointment =" + id + ";";

        // Ejecutar la consulta usando executeCommit
        return CRUD.executeCommit(query);
    }

    public static boolean deleteAppointment(int id) throws SQLException {
        CRUD.setConnection(ConexionDB.getConexion());
        String query = "DELETE FROM Appointments WHERE ID_Appointment =" + id + ";";
        return CRUD.executeCommit(query);
    }

    // Obtener una cita por su ID
    public static Appointment getAppointment(int id) throws SQLException {
        CRUD.setConnection(ConexionDB.getConexion());

        // Consulta para obtener la cita por ID
        String sql = "SELECT * FROM Appointments WHERE ID_Appointment = " + id + ";";

        // Ejecutar la consulta
        try (ResultSet rs = CRUD.queryDB(sql)) {
            // Crear un objeto Appointment
            Appointment appointment = new Appointment();

            // Verificar si se obtuvo algún resultado
            if (rs.next()) {
                appointment.setIdAppointment(rs.getInt("ID_Appointment"));

                // Convertir la fecha de la cita de Timestamp a LocalDateTime
                appointment.setDateAppointment(rs.getTimestamp("DateAppointment").toLocalDateTime());

                // Obtener y establecer el motivo de la cita
                appointment.setReason(rs.getString("Reason"));

                // Obtener el estado de la cita
                int stateId = rs.getInt("ID_State");
                State state = new State(stateId);
                appointment.setState(state);

                // Obtener la ID del animal asociado y cargar su información
                int idPet = rs.getInt("ID_Pet");
                Animal animal = PetControlador.getPetById(idPet);  // Método hipotético para obtener el animal
                appointment.setMascota(animal);

            } else {
                // Si no se encuentra la cita, devolver null
                return null;
            }

            return appointment;  // Devolver la cita
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            return null;  // Devolver null en caso de error
        } finally {
            CRUD.closeConnection();  // Asegurarse de cerrar la conexión
        }
    }

    public static List<Appointment> listAppointments() throws SQLException {
        List<Appointment> appointmentList = new ArrayList<>();

        String sql = "SELECT * FROM Appointments";

        // Usar try-with-resources para manejar ResultSet y Statement
        try (Connection conn = ConexionDB.getConexion(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Appointment appointment = new Appointment();
                appointment.setIdAppointment(rs.getInt("ID_Appointment"));

                // Comprobar si el valor de la fecha es null antes de convertirlo
                if (rs.getTimestamp("DateAppointment") != null) {
                    appointment.setDateAppointment(rs.getTimestamp("DateAppointment").toLocalDateTime());
                } else {
                    appointment.setDateAppointment(null);  // O cualquier otro valor que necesites
                }

                appointment.setReason(rs.getString("Reason"));

                // Obtener el estado y asociarlo a la cita
                int s = rs.getInt("ID_State");
                State state = new State(s);
                appointment.setState(state);

                // Agregar la cita a la lista
                appointmentList.add(appointment);
            }

        } catch (SQLException ex) {
            System.out.println("Error al listar las citas: " + ex.getMessage());
            ex.printStackTrace();  // Mejor para depurar
        }

        return appointmentList;
    }

    public static int getLastServiceID() throws SQLException {
        CRUD.setConnection(ConexionDB.getConexion());
        String query = "SELECT MAX(ID_Appointment) AS last_id FROM Appointments;";

        ResultSet rs = CRUD.queryDB(query);
        int lastId = -1;

        try {
            if (rs.next()) {
                lastId = rs.getInt("last_id");
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        } finally {
            CRUD.closeConnection();
        }

        return lastId;
    }
}
