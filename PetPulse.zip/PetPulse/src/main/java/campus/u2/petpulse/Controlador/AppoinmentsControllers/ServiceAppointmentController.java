/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package campus.u2.petpulse.Controlador.AppoinmentsControllers;

import campus.u2.petpulse.Persistencia.CRUD;
import campus.u2.petpulse.Persistencia.ConexionDB;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ServiceAppointmentController {

    public static boolean registerServiceAppointment(int idService, int idAppointment, int idEmployee) throws SQLException {
        CRUD.setConnection(ConexionDB.getConexion());
        String query = "INSERT INTO serviceAppointments (ID_Service, ID_Appointment, ID_Employee) VALUES ("
                + idService + ", " + idAppointment + ", " + idEmployee + ");";
        return CRUD.executeCommit(query);
    }

    public static boolean updateServiceAppointment(int idService, int idAppointment, int newIdEmployee) throws SQLException {
        CRUD.setConnection(ConexionDB.getConexion());
        String query = "UPDATE serviceAppointments SET ID_Employee=" + newIdEmployee
                + " WHERE ID_Service=" + idService + " AND ID_Appointment=" + idAppointment + ";";
        return CRUD.executeCommit(query);
    }

    public static boolean deleteServiceAppointment(int idService, int idAppointment) throws SQLException {
        CRUD.setConnection(ConexionDB.getConexion());
        String query = "DELETE FROM serviceAppointments WHERE ID_Service=" + idService + " AND ID_Appointment=" + idAppointment + ";";
        return CRUD.executeCommit(query);
    }

}
