/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package campus.u2.petpulse.Controlador.AppoinmentsControllers;

import campus.u2.petpulse.Clases.Services.Service;
import campus.u2.petpulse.Clases.Services.VeterinaryMediator;
import campus.u2.petpulse.Clases.Users.Veterinarian;
import campus.u2.petpulse.Clases.Appointments.Appointment;
import campus.u2.petpulse.Controlador.ServicesControlleres.ServiceController;
import campus.u2.petpulse.Controlador.Users.VeterinarianControlador;
import java.sql.SQLException;



public class VeterinaryMediatorController {

    private VeterinaryMediator mediator;

    public VeterinaryMediatorController() {
        this.mediator = new VeterinaryMediator();
    }

    public boolean registerServiceAppointment(int idService, int idAppointment, int idEmployee) throws SQLException {
        if (ServiceAppointmentController.registerServiceAppointment(idService, idAppointment, idEmployee)) {
            Appointment appointment = getAppointmentById(idAppointment);
            Service service = getServiceById(idService);
            Veterinarian veterinarian = getVeterinarianById(idEmployee);

            if (appointment == null || service == null || veterinarian == null) {
                throw new IllegalStateException("Appointment, Service, or Veterinarian not found.");
            }

            mediator.addServiceAppointment(appointment, service);
            return true;
        }
        return false;
    }

    public boolean deleteServiceAppointment(int idService, int idAppointment) throws SQLException {
        if (ServiceAppointmentController.deleteServiceAppointment(idService, idAppointment)) {
            Appointment appointment = getAppointmentById(idAppointment);
            Service service = getServiceById(idService);

            if (appointment == null || service == null) {
                throw new IllegalStateException("Appointment or Service not found.");
            }

            mediator.removeServiceFromAppointment(appointment, service);
            return true;
        }
        return false;
    }

    private Appointment getAppointmentById(int idAppointment) throws SQLException {
        Appointment appointment = AppointmentController.getAppointment(idAppointment);
        if (appointment == null) {
            throw new IllegalStateException("Appointment not found with ID: " + idAppointment);
        }
        return appointment;
    }

    private Service getServiceById(int idService) throws SQLException {
        Service service = ServiceController.getService(idService);
        if (service == null) {
            throw new IllegalStateException("Service not found with ID: " + idService);
        }
        return service;
    }

    private Veterinarian getVeterinarianById(int id) throws SQLException {
        Veterinarian veterinarian = VeterinarianControlador.getVeterinarianById(id);
        if (veterinarian == null) {
            throw new IllegalStateException("Veterinarian not found with ID: " + id);
        }
        return veterinarian;
    }

    public VeterinaryMediator getMediator() {
        return mediator;
    }
}
