package campus.u2.petpulse.Controlador.Users;

import campus.u2.petpulse.Clases.BillingProcess.Invoice;
import campus.u2.petpulse.Persistencia.CRUD;
import campus.u2.petpulse.Persistencia.ConexionDB;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class InvoicesControlador {

    // Insertar una factura
    public static boolean insertInvoice(  Integer idOwner) {
        String query = "INSERT INTO Invoices(DateInvoice, State, ID_Owner) VALUES(?, ?, ?)";
        Invoice invoice = new Invoice(  idOwner);

        try {
            CRUD.setConnection(ConexionDB.getConexion());
            if (CRUD.setAutoCommitDB(false)) {
                boolean result = CRUD.insertIntoDB(query, invoice.getDateInvoice(), invoice.getState(), invoice.getIdOwner());
                if (result) {
                    CRUD.commitDB();
                } else {
                    CRUD.rollbackDB();
                }
                return result;
            }
        } catch (SQLException e) {
            System.out.println("Error en la operación de inserción: " + e.getMessage());
            CRUD.rollbackDB();
        } finally {
            CRUD.closeConnection();
        }

        return false;
    }

    // Actualizar una factura
    public static boolean updateInvoice(int CUFE,  Boolean state, Integer idOwner) throws SQLException {
        String query = "UPDATE Invoices SET DateInvoice = ?, State = ?, ID_Owner = ? WHERE CUFE = ?";
        Invoice invoice = new Invoice(CUFE,  state, idOwner);

        try {
            CRUD.setConnection(ConexionDB.getConexion());
            if (CRUD.setAutoCommitDB(false)) {
                boolean result = CRUD.updateInDB(query, invoice.getDateInvoice(), invoice.getState(), invoice.getIdOwner(), invoice.getCUFE());
                if (result) {
                    CRUD.commitDB();
                } else {
                    CRUD.rollbackDB();
                }
                return result;
            }
        } catch (SQLException e) {
            System.out.println("Error en la operación de actualización: " + e.getMessage());
            CRUD.rollbackDB();
            throw e;
        } finally {
            CRUD.closeConnection();
        }

        return false;
    }

    // Eliminar una factura
    public static boolean deleteInvoice(int CUFE) throws SQLException {
        String query = "DELETE FROM Invoices WHERE CUFE = ?";

        try {
            CRUD.setConnection(ConexionDB.getConexion());
            if (CRUD.setAutoCommitDB(false)) {
                boolean result = CRUD.deleteFromDB(query, CUFE);
                if (result) {
                    CRUD.commitDB();
                } else {
                    CRUD.rollbackDB();
                }
                return result;
            }
        } catch (SQLException e) {
            System.out.println("Error en la operación de eliminación: " + e.getMessage());
            CRUD.rollbackDB();
            throw e;
        } finally {
            CRUD.closeConnection();
        }

        return false;
    }

    // Obtener una factura por ID
    public static Invoice getInvoiceById(int CUFE) throws SQLException {
        String query = "SELECT * FROM Invoices WHERE CUFE = ?";

        try {
            CRUD.setConnection(ConexionDB.getConexion());
            ResultSet rs = CRUD.queryDB(query, CUFE);

            if (rs.next()) {
                Invoice invoice = new Invoice(
                        rs.getInt("CUFE"),
                        rs.getBoolean("State"),
                       
                        rs.getInt("ID_Owner"),
                         rs.getDouble("Total")
                );
                rs.close();
                return invoice;
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener la factura: " + e.getMessage());
            CRUD.rollbackDB();
            throw e;
        } finally {
            CRUD.closeConnection();
        }

        return null;
    }

    // Listar todas las facturas
    public static List<Invoice> listInvoices() throws SQLException {
        String query = "SELECT * FROM Invoices";
        List<Invoice> invoicesList = new ArrayList<>();

        try {
            CRUD.setConnection(ConexionDB.getConexion());
            ResultSet rs = CRUD.queryDB(query);

            while (rs.next()) {
                Invoice invoice = new Invoice(
                      rs.getInt("CUFE"),
                        rs.getBoolean("State"),
                       
                        rs.getInt("ID_Owner"),
                         rs.getDouble("Total")
                );
                invoicesList.add(invoice);
            }
            rs.close();
        } catch (SQLException e) {
            System.out.println("Error al listar las facturas: " + e.getMessage());
            CRUD.rollbackDB();
            throw e;
        } finally {
            CRUD.closeConnection();
        }

        return invoicesList;
    }
    
    public static List<Invoice> listInvoicesByState(boolean state) throws SQLException {
    String query = "SELECT * FROM Invoices WHERE State = ?";
    List<Invoice> invoicesList = new ArrayList<>();

    try {
        CRUD.setConnection(ConexionDB.getConexion());
        ResultSet rs = CRUD.queryDB(query, state);

        while (rs.next()) {
            Invoice invoice = new Invoice(
                    rs.getInt("CUFE"),
                    rs.getInt("ID_Owner")
            );
            invoicesList.add(invoice);
        }
        rs.close();
    } catch (SQLException e) {
        System.out.println("Error al listar las facturas por estado: " + e.getMessage());
        CRUD.rollbackDB();
        throw e;
    } finally {
        CRUD.closeConnection();
    }

    return invoicesList;
}
    
    public static int getLastInvoiceID() throws SQLException {
    String query = "SELECT MAX(CUFE) AS last_id FROM Invoices";

    CRUD.setConnection(ConexionDB.getConexion());
    ResultSet rs = CRUD.queryDB(query);
    int lastId = -1;

    try {
        if (rs.next()) {
            lastId = rs.getInt("last_id");
        }
    } catch (SQLException e) {
        System.out.println("Error al obtener el último ID de factura: " + e.getMessage());
        throw e;
    } finally {
        rs.close();
        CRUD.closeConnection();
    }

    return lastId;
}


}
