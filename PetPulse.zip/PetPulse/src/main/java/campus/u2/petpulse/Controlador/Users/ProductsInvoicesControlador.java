package campus.u2.petpulse.Controlador.Users;

import campus.u2.petpulse.Clases.BillingProcess.ProductsInvoice;
import campus.u2.petpulse.Persistencia.CRUD;
import campus.u2.petpulse.Persistencia.ConexionDB;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductsInvoicesControlador {

    // Insertar una factura de producto
    public static boolean insertProductsInvoice(int CUFE, int ID_Product, int quantity) {
        String query = "INSERT INTO ProductsInvoices(CUFE, ID_Product, Quantity) VALUES(?, ?, ?)";
        ProductsInvoice productsInvoice = new ProductsInvoice(CUFE, ID_Product, quantity);

        try {
            CRUD.setConnection(ConexionDB.getConexion());
            if (CRUD.setAutoCommitDB(false)) {
                boolean result = CRUD.insertIntoDB(query, productsInvoice.getCUFE(), productsInvoice.getID_Product(), productsInvoice.getQuantity());
                if (result) {
                    CRUD.commitDB();
                } else {
                    CRUD.rollbackDB();
                }
                return result;
            }
        } catch (SQLException e) {
            System.out.println("Error en la operación de inserción: " + e.getMessage());
            CRUD.rollbackDB();
        } finally {
            CRUD.closeConnection();
        }

        return false;
    }

    // Actualizar una factura de producto
    public static boolean updateProductsInvoice(int CUFE, int ID_Product, int quantity) throws SQLException {
        String query = "UPDATE ProductsInvoices SET Quantity = ? WHERE CUFE = ? AND ID_Product = ?";
        ProductsInvoice productsInvoice = new ProductsInvoice(CUFE, ID_Product, quantity);

        try {
            CRUD.setConnection(ConexionDB.getConexion());
            if (CRUD.setAutoCommitDB(false)) {
                boolean result = CRUD.updateInDB(query, productsInvoice.getQuantity(), productsInvoice.getCUFE(), productsInvoice.getID_Product());
                if (result) {
                    CRUD.commitDB();
                } else {
                    CRUD.rollbackDB();
                }
                return result;
            }
        } catch (SQLException e) {
            System.out.println("Error en la operación de actualización: " + e.getMessage());
            CRUD.rollbackDB();
            throw e;
        } finally {
            CRUD.closeConnection();
        }

        return false;
    }

    // Eliminar una factura de producto
    public static boolean deleteProductsInvoice(int CUFE, int ID_Product) throws SQLException {
        String query = "DELETE FROM ProductsInvoices WHERE CUFE = ? AND ID_Product = ?";

        try {
            CRUD.setConnection(ConexionDB.getConexion());
            if (CRUD.setAutoCommitDB(false)) {
                boolean result = CRUD.deleteFromDB(query, CUFE, ID_Product);
                if (result) {
                    CRUD.commitDB();
                } else {
                    CRUD.rollbackDB();
                }
                return result;
            }
        } catch (SQLException e) {
            System.out.println("Error en la operación de eliminación: " + e.getMessage());
            CRUD.rollbackDB();
            throw e;
        } finally {
            CRUD.closeConnection();
        }

        return false;
    }

    // Obtener una factura de producto por ID
    public static ProductsInvoice getProductsInvoiceById(int CUFE, int ID_Product) throws SQLException {
        String query = "SELECT * FROM ProductsInvoices WHERE CUFE = ? AND ID_Product = ?";

        try {
            CRUD.setConnection(ConexionDB.getConexion());
            ResultSet rs = CRUD.queryDB(query, CUFE, ID_Product);

            if (rs.next()) {
                ProductsInvoice productsInvoice = new ProductsInvoice(
                        rs.getInt("CUFE"),
                        rs.getInt("ID_Product"),
                        rs.getInt("Quantity")
                );
                rs.close();
                return productsInvoice;
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener la factura de producto: " + e.getMessage());
            CRUD.rollbackDB();
            throw e;
        } finally {
            CRUD.closeConnection();
        }

        return null;
    }

    // Listar todas las facturas de producto
    public static List<ProductsInvoice> listProductsInvoices() throws SQLException {
        String query = "SELECT * FROM ProductsInvoices";
        List<ProductsInvoice> productsInvoicesList = new ArrayList<>();

        try {
            CRUD.setConnection(ConexionDB.getConexion());
            ResultSet rs = CRUD.queryDB(query);

            while (rs.next()) {
                ProductsInvoice productsInvoice = new ProductsInvoice(
                        rs.getInt("CUFE"),
                        rs.getInt("ID_Product"),
                        rs.getInt("Quantity")
                );
                productsInvoicesList.add(productsInvoice);
            }
            rs.close();
        } catch (SQLException e) {
            System.out.println("Error al listar las facturas de producto: " + e.getMessage());
            CRUD.rollbackDB();
            throw e;
        } finally {
            CRUD.closeConnection();
        }

        return productsInvoicesList;
    }
}
