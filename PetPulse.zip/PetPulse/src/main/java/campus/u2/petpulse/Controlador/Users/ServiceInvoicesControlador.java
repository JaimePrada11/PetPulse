package campus.u2.petpulse.Controlador.Users;

import campus.u2.petpulse.Clases.BillingProcess.ServiceInvoice;
import campus.u2.petpulse.Persistencia.CRUD;
import campus.u2.petpulse.Persistencia.ConexionDB;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ServiceInvoicesControlador {

    // Insertar una factura de servicio
    public static boolean insertServiceInvoice(int CUFE, int idService, int idEmployee, int idPet, double performance, String observations) {
        String query = "INSERT INTO ServiceInvoices(CUFE, ID_Service, ID_Employee, ID_Pet, Performance, Observations) VALUES(?, ?, ?, ?, ?, ?)";
        ServiceInvoice serviceInvoice = new ServiceInvoice(CUFE, idService, idEmployee, idPet, performance, observations);

        try {
            CRUD.setConnection(ConexionDB.getConexion());
            if (CRUD.setAutoCommitDB(false)) {
                boolean result = CRUD.insertIntoDB(query, serviceInvoice.getCUFE(), serviceInvoice.getIdService(), serviceInvoice.getIdEmployee(), serviceInvoice.getIdPet(), serviceInvoice.getPerformance(), serviceInvoice.getObservations());
                if (result) {
                    CRUD.commitDB();
                } else {
                    CRUD.rollbackDB();
                }
                return result;
            }
        } catch (SQLException e) {
            System.out.println("Error en la operación de inserción: " + e.getMessage());
            CRUD.rollbackDB();
        } finally {
            CRUD.closeConnection();
        }

        return false;
    }

    // Actualizar una factura de servicio
    public static boolean updateServiceInvoice(int CUFE, int idService, int idEmployee, int idPet, double performance, String observations) throws SQLException {
        String query = "UPDATE ServiceInvoices SET ID_Employee = ?, ID_Pet = ?, Performance = ?, Observations = ? WHERE CUFE = ? AND ID_Service = ?";
        ServiceInvoice serviceInvoice = new ServiceInvoice(CUFE, idService, idEmployee, idPet, performance, observations);

        try {
            CRUD.setConnection(ConexionDB.getConexion());
            if (CRUD.setAutoCommitDB(false)) {
                boolean result = CRUD.updateInDB(query, serviceInvoice.getIdEmployee(), serviceInvoice.getIdPet(), serviceInvoice.getPerformance(), serviceInvoice.getObservations(), serviceInvoice.getCUFE(), serviceInvoice.getIdService());
                if (result) {
                    CRUD.commitDB();
                } else {
                    CRUD.rollbackDB();
                }
                return result;
            }
        } catch (SQLException e) {
            System.out.println("Error en la operación de actualización: " + e.getMessage());
            CRUD.rollbackDB();
            throw e;
        } finally {
            CRUD.closeConnection();
        }

        return false;
    }

    // Eliminar una factura de servicio
    public static boolean deleteServiceInvoice(int CUFE, int idService) throws SQLException {
        String query = "DELETE FROM ServiceInvoices WHERE CUFE = ? AND ID_Service = ?";

        try {
            CRUD.setConnection(ConexionDB.getConexion());
            if (CRUD.setAutoCommitDB(false)) {
                boolean result = CRUD.deleteFromDB(query, CUFE, idService);
                if (result) {
                    CRUD.commitDB();
                } else {
                    CRUD.rollbackDB();
                }
                return result;
            }
        } catch (SQLException e) {
            System.out.println("Error en la operación de eliminación: " + e.getMessage());
            CRUD.rollbackDB();
            throw e;
        } finally {
            CRUD.closeConnection();
        }

        return false;
    }

    

    // Listar todas las facturas de servicio
    public static List<ServiceInvoice> listServiceInvoices() throws SQLException {
        String query = "SELECT * FROM ServiceInvoices";
        List<ServiceInvoice> serviceInvoicesList = new ArrayList<>();

        try {
            CRUD.setConnection(ConexionDB.getConexion());
            ResultSet rs = CRUD.queryDB(query);

            while (rs.next()) {
                ServiceInvoice serviceInvoice = new ServiceInvoice(
                        rs.getInt("CUFE"),
                        rs.getInt("ID_Service"),
                        rs.getInt("ID_Employee"),
                        rs.getInt("ID_Pet"),
                        rs.getDouble("Performance"),
                        rs.getString("Observations")
                );
                serviceInvoicesList.add(serviceInvoice);
            }
            rs.close();
        } catch (SQLException e) {
            System.out.println("Error al listar las facturas de servicio: " + e.getMessage());
            CRUD.rollbackDB();
            throw e;
        } finally {
            CRUD.closeConnection();
        }

        return serviceInvoicesList;
    }
    
    // Obtener una factura de servicio por ID
public static ServiceInvoice getServiceInvoiceById(int CUFE, int idService) throws SQLException {
    String query = "SELECT * FROM ServiceInvoices WHERE CUFE = ? AND ID_Service = ?";
    ServiceInvoice serviceInvoice = null;

    try {
        CRUD.setConnection(ConexionDB.getConexion());
        ResultSet rs = CRUD.queryDB(query, CUFE, idService);

        if (rs.next()) {
            serviceInvoice = new ServiceInvoice(
                    rs.getInt("CUFE"),
                    rs.getInt("ID_Service"),
                    rs.getInt("ID_Employee"),
                    rs.getInt("ID_Pet"),
                    rs.getDouble("Performance"),
                    rs.getString("Observations")
            );
        }
        rs.close();
    } catch (SQLException e) {
        System.out.println("Error al obtener la factura de servicio: " + e.getMessage());
        CRUD.rollbackDB();
        throw e;
    } finally {
        CRUD.closeConnection();
    }

    return serviceInvoice;
}

}
