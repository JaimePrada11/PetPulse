package campus.u2.petpulse.Vista;





import campus.u2.petpulse.Vista.MenuFunction.GeneralMenu;
import java.sql.SQLException;




public class Menu {

  
    public static void main(String[] args) throws SQLException {
 
        
        
    GeneralMenu.mainGeneral();
        
        
    }

}
