/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package campus.u2.petpulse.Vista.MenuFunction;

import campus.u2.petpulse.Clases.BillingProcess.Purchase;
import campus.u2.petpulse.Clases.BillingProcess.PurchaseDetails;
import campus.u2.petpulse.Controlador.ProductsControlleres.ProductController;
import campus.u2.petpulse.Controlador.Users.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author LENOVO
 */
public class AdministratorMenu {

    private static final Scanner scanner = new Scanner(System.in);

    public static void menuAdministrator() {
        while (true) {
            try {
                System.out.println("\n---- Administrator Menu ----");
                System.out.println("1. Manage Orders");
                System.out.println("2. Invoice management");
                System.out.println("3. Owners management");
                System.out.println("4. Employees management");
                System.out.println("5. Suppliers");
                System.out.println("6. Animals Management");
                System.out.println("7. Product Management");
                System.out.println("8. Service Management");
                System.out.println("9. Inner invoice management");
                System.out.println("0. Back to General Menu");

                System.out.print("Select an option: ");

                int option = scanner.nextInt();
                scanner.nextLine();

                switch (option) {
                    case 1:
                        manageOrders();
                        break;

                    case 2:
                        manageInvoices();
                        break;

                    case 3:
                        MenuFunctions.mostrarMenuOwner();
                        break;

                    case 4:
                        VeterinarianMenu.menuVeterinarios();
                        break;

                    case 5:
                        SuppliersMenu.menuSuppliers();
                        break;

                    case 6:
                        MenuAnimals.mostrarMenuMascotas();
                        break;

                    case 7: {
                        try {
                            ProductMenuFunction.showMenu();
                        } catch (SQLException ex) {
                            Logger.getLogger(AdministratorMenu.class.getName()).log(Level.SEVERE, null, ex);
                            System.out.println("An error occurred while managing products.");
                        }
                    }
                    break;

                    case 8: {
                        try {
                            ServiceMenuFunction.showMenu();
                        } catch (SQLException ex) {
                            Logger.getLogger(AdministratorMenu.class.getName()).log(Level.SEVERE, null, ex);
                            System.out.println("An error occurred while managing services.");
                        }
                    }
                    break;
                    case 9: 
                       InvoiceManagement.maininvoice(); 

                    case 0:
                        return;

                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            } catch (Exception ex) {
                System.out.println("An unexpected error occurred: " + ex.getMessage());
                scanner.nextLine(); // Limpia el buffer en caso de error de entrada
            }
        }
    }

    public static void manageOrders() {
        while (true) {
            System.out.println("\n---- Manage Orders ----");
            System.out.println("1. Create Purshase");
            System.out.println("2. List Orders");
            System.out.println("3. Search Order by ID");
            System.out.println("4. Update Order");
            System.out.println("5. Delete Order");
            System.out.println("0. Back to Administrator Menu");
            System.out.print("Select an option: ");

            int option = scanner.nextInt();
            scanner.nextLine();

            switch (option) {
                case 1:
                    createPurshase();
                    break;
                case 2:
                    listOrders();
                    break;
                case 3:
                    searchOrderById();
                    break;
                case 4:
                    updateOrder();
                    break;
                case 5:
                    deleteOrder();
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    public static void createPurshase() {
        System.out.println("\n---- Create Purchase ----");
        System.out.print("Enter Supplier ID: ");
        int supplierId = scanner.nextInt();
        System.out.print("Enter Purchase Date (YYYY-MM-DD): ");
        String dateStr = scanner.next();
        LocalDate date = LocalDate.parse(dateStr);
        scanner.nextLine();
        boolean result = PurchasesControlador.insertPurchase(date, supplierId);
        if (result) {
            System.out.println("Purchase created successfully.");
            System.out.print("Do you want to add items to this purchase? (yes/no): ");
            String addItems = scanner.nextLine();
            if (addItems.equalsIgnoreCase("yes")) {
                while (true) {
                    try {
                        for (int i = 0; i < ProductController.listProducts().size(); i++) {
                            System.out.println(ProductController.listProducts().get(i).getName());
                            System.out.println(ProductController.listProducts().get(i).getPrice());
                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(AdministratorMenu.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    System.out.print("Enter Product ID: ");
                    int productId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter Quantity: ");
                    int quantity = scanner.nextInt();
                    scanner.nextLine();
                    double subtotal = 0.0;
                    try {
                        subtotal = ProductController.getProductId(productId).getPrice() * quantity;
                    } catch (SQLException ex) {
                        Logger.getLogger(AdministratorMenu.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    int id = 0;
                    try {
                        id = PurchasesControlador.getLastPurchaseID();
                    } catch (SQLException ex) {
                        Logger.getLogger(AdministratorMenu.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    boolean itemResult = PurchaseDetailsControlador.insertPurchaseDetail(productId, id, quantity, subtotal);
                    if (itemResult) {
                        System.out.println("Item added to purchase.");
                    } else {
                        System.out.println("Error adding item to purchase.");
                    }
                    System.out.print("Do you want to add another item? (yes/no): ");
                    String anotherItem = scanner.nextLine();
                    if (anotherItem.equalsIgnoreCase("no")) {
                        break;
                    }
                }
            }
        } else {
            System.out.println("Error creating the purchase.");
        }
    }

    public static void createOrder() {
        System.out.println("\n---- Create Order ----");
        System.out.print("Product ID: ");
        int productId = scanner.nextInt();
        System.out.print("Purchase ID: ");
        int purchaseId = scanner.nextInt();
        System.out.print("Quantity: ");
        int quantity = scanner.nextInt();
        System.out.print("Subtotal: ");
        double subtotal = 0.0;
        try {
            subtotal = ProductController.getProductId(productId).getPrice() * quantity;
        } catch (SQLException ex) {
            Logger.getLogger(AdministratorMenu.class.getName()).log(Level.SEVERE, null, ex);
        }

        boolean result = PurchaseDetailsControlador.insertPurchaseDetail(productId, purchaseId, quantity, subtotal);
        if (result) {
            System.out.println("Order created successfully.");
        } else {
            System.out.println("Error creating the order.");
        }
    }

    public static void listOrders() {
        try {
            List<PurchaseDetails> orders = PurchaseDetailsControlador.listPurchaseDetails();
            if (orders.isEmpty()) {
                System.out.println("No orders found.");
            } else {
                for (PurchaseDetails order : orders) {
                    System.out.println(order);
                }
            }
        } catch (Exception e) {
            System.out.println("Error listing orders: " + e.getMessage());
        }
    }

    public static void searchOrderById() {
        try {
            System.out.print("Enter Purchase ID: ");
            int purchaseId = scanner.nextInt();
            scanner.nextLine();
            List<PurchaseDetails> orders = PurchaseDetailsControlador.getPurchaseDetailsByPurchaseId(purchaseId);
            if (orders.isEmpty()) {
                System.out.println("No orders found for the given ID.");
            } else {
                for (PurchaseDetails order : orders) {
                    System.out.println(order);
                }
            }
        } catch (Exception e) {
            System.out.println("Error searching order by ID: " + e.getMessage());
        }
    }

    public static void updateOrder() {
        System.out.println("\n---- Update Order ----");
        System.out.print("Product ID: ");
        int productId = scanner.nextInt();
        System.out.print("Purchase ID: ");
        int purchaseId = scanner.nextInt();
        System.out.print("New Quantity: ");
        int quantity = scanner.nextInt();

        double subtotal = 0.0;
        try {
            subtotal = ProductController.getProductId(productId).getPrice() * quantity;
        } catch (SQLException ex) {
            Logger.getLogger(AdministratorMenu.class.getName()).log(Level.SEVERE, null, ex);
        }

        boolean result = PurchaseDetailsControlador.updatePurchaseDetail(productId, purchaseId, quantity, subtotal);
        if (result) {
            System.out.println("Order updated successfully.");
        } else {
            System.out.println("Error updating the order.");
        }
    }

    public static void deleteOrder() {
        System.out.println("\n---- Delete Order ----");
        System.out.print("Product ID: ");
        int productId = scanner.nextInt();
        System.out.print("Purchase ID: ");
        int purchaseId = scanner.nextInt();
        scanner.nextLine();

        boolean result = PurchaseDetailsControlador.deletePurchaseDetail(productId, purchaseId);
        if (result) {
            System.out.println("Order deleted successfully.");
        } else {
            System.out.println("Error deleting the order.");
        }
    }

    public static void manageInvoices() {
        while (true) {
            System.out.println("\n---- Manage Invoices ----");
            System.out.println("1. List Pending Invoices");
            System.out.println("2. List Paid Invoices");
            System.out.println("3. Pay Invoice");
            System.out.println("4. View Invoice by ID");
            System.out.println("5. Back to Administrator Menu");
            System.out.print("Select an option: ");
            int option = scanner.nextInt();
            scanner.nextLine();
            switch (option) {
                case 1:
                    listPendingInvoices();
                    break;
                case 2:
                    listPaidInvoices();
                    break;
                case 3:
                    payInvoice();
                    break;
                case 4:
                    viewInvoiceById();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    public static void listPendingInvoices() {
        try {
            List<Purchase> pendingInvoices = PurchasesControlador.listPendingPurchases();
            if (pendingInvoices.isEmpty()) {
                System.out.println("No pending invoices found.");
            } else {
                for (Purchase purchase : pendingInvoices) {
                    int id = purchase.getId_Purchase();
                    viewInvoiceById(id);
                }
            }
        } catch (Exception e) {
            System.out.println("Error listing pending invoices: " + e.getMessage());
        }
    }

    public static void listPaidInvoices() {
        try {
            List<Purchase> paidInvoices = PurchasesControlador.listPaidPurchases();
            if (paidInvoices.isEmpty()) {
                System.out.println("No paid invoices found.");
            } else {
                for (Purchase purchase : paidInvoices) {
                    int id = purchase.getId_Purchase();
                    viewInvoiceById(id);

                }
            }
        } catch (Exception e) {
            System.out.println("Error listing paid invoices: " + e.getMessage());
        }
    }

    public static void payInvoice() {
        try {
            System.out.print("Enter Invoice ID to pay: ");
            int invoiceId = scanner.nextInt();
            scanner.nextLine();
            boolean result = PurchasesControlador.payInvoice(invoiceId);
            if (result) {
                System.out.println("Invoice paid successfully.");
            } else {
                System.out.println("Error paying the invoice.");
            }
        } catch (Exception e) {
            System.out.println("Error paying the invoice: " + e.getMessage());
        }
    }

    public static void viewInvoiceById() {
        try {
            System.out.print("Enter Invoice ID to view: ");
            int invoiceId = scanner.nextInt();
            scanner.nextLine();
            String invoice = PurchasesControlador.getPurchaseInvoice(invoiceId);
            System.out.println(invoice);
        } catch (Exception e) {
            System.out.println("Error viewing the invoice: " + e.getMessage());
        }
    }

    public static void viewInvoiceById(int id) {
        try {

            int invoiceId = id;

            String invoice = PurchasesControlador.getPurchaseInvoice(invoiceId);
            System.out.println(invoice);
        } catch (Exception e) {
            System.out.println("Error viewing the invoice: " + e.getMessage());
        }
    }

}
