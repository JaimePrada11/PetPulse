
package campus.u2.petpulse.Vista.MenuFunction;

import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GeneralMenu {

    private static final Scanner scanner = new Scanner(System.in);

    public static void mainGeneral() {
        while (true) {
            System.out.println("\n---- General Veterinary Clinic Menu ----");
            System.out.println("1. Administrator");
            System.out.println("2. Employee");
            System.out.println("3. Exit");
            System.out.print("Select your role: ");

            int role = scanner.nextInt();
            scanner.nextLine();

            switch (role) {
                case 1:
                    AdministratorMenu.menuAdministrator();
                    break;
                case 2:
                    try {
                        menuEmployee();
                    } catch (Exception e) {
                        Logger.getLogger(GeneralMenu.class.getName()).log(Level.SEVERE, null, e);
                        System.out.println("An error occurred. Please try again.");
                    }
                    break;
                case 3:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    public static void menuEmployee() {
        while (true) {
            try {
                System.out.println("\n---- Employee Management Menu ----");
                System.out.println("1. Create Invoice");
                System.out.println("2. Change Invoice State");
                System.out.println("3. List Pending Invoices");
                System.out.println("4. Find Invoice by ID");
                System.out.println("5. Add Products to Existing Invoice");
                System.out.println("6. Show Pets Menu");
                System.out.println("7. Show Emergency Contact Menu");
                System.out.println("8. Show Owner Menu");
                System.out.println("9. Show Product Menu");
                System.out.println("10. Show Service Menu");
                System.out.println("11. Show Suppliers Menu");
                System.out.println("12. Show Veterinarians Menu");
                System.out.println("13. Exit");
                System.out.print("Select an option: ");
                int option = scanner.nextInt();
                scanner.nextLine();

                switch (option) {
                    case 1:
                        InvoiceManagement.createInvoice();
                        break;
                    case 2:
                        InvoiceManagement.changeInvoiceState();
                        break;
                    case 3:
                        InvoiceManagement.listPendingInvoices();
                        break;
                    case 4:
                        InvoiceManagement.findInvoiceById();
                        break;
                    case 5:
                        InvoiceManagement.addProductsToExistingInvoice();
                        break;
                    case 6:
                        MenuAnimals.mostrarMenuMascotas();
                        break;
                    case 7:
                        MenuEmergencyContact.MenuEmergency();
                        break;
                    case 8:
                        MenuFunctions.mostrarMenuOwner();
                        break;
                    case 9:
                        try {
                            ProductMenuFunction.showMenu();
                        } catch (SQLException ex) {
                            Logger.getLogger(GeneralMenu.class.getName()).log(Level.SEVERE, null, ex);
                            System.out.println("Error displaying product menu: " + ex.getMessage());
                        }
                        break;
                    case 10:
                        try {
                            ServiceMenuFunction.showMenu();
                        } catch (SQLException ex) {
                            Logger.getLogger(GeneralMenu.class.getName()).log(Level.SEVERE, null, ex);
                            System.out.println("Error displaying service menu: " + ex.getMessage());
                        }
                        break;
                    case 11:
                        SuppliersMenu.menuSuppliers();
                        break;
                    case 12:
                        VeterinarianMenu.menuVeterinarios();
                        break;
                    case 13:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            } catch (Exception e) {
                Logger.getLogger(GeneralMenu.class.getName()).log(Level.SEVERE, null, e);
                System.out.println("An error occurred. Please try again.");
            }
        }
    }
}
