package campus.u2.petpulse.Vista.MenuFunction;

import campus.u2.petpulse.Controlador.Users.InvoicesControlador;
import campus.u2.petpulse.Controlador.Users.ProductsInvoicesControlador;
import campus.u2.petpulse.Clases.BillingProcess.Invoice;
import campus.u2.petpulse.Clases.BillingProcess.ProductsInvoice;
import campus.u2.petpulse.Clases.BillingProcess.ServiceInvoice;
import campus.u2.petpulse.Controlador.ProductsControlleres.ProductController;
import campus.u2.petpulse.Controlador.ServicesControlleres.ServiceController;
import campus.u2.petpulse.Persistencia.CRUD;
import campus.u2.petpulse.Persistencia.ConexionDB;
import java.sql.ResultSet;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class InvoiceManagement {

    private static final Scanner scanner = new Scanner(System.in);

    public static void createInvoice() {
        System.out.println("\n---- Create Invoice ----");
        System.out.print("Enter Owner ID: ");
        int ownerId = scanner.nextInt();
        System.out.print("Enter Invoice Date (YYYY-MM-DD): ");
        String dateStr = scanner.next();
        LocalDate date = LocalDate.parse(dateStr);
        scanner.nextLine();
        boolean result = InvoicesControlador.insertInvoice(ownerId);
        if (result) {
            System.out.println("Invoice created successfully.");
            System.out.print("Do you want to add products to this invoice? (yes/no): ");
            String addProducts = scanner.nextLine();
            if (addProducts.equalsIgnoreCase("yes")) {
                addProductsToInvoice(getLastInvoiceId());
            }
        } else {
            System.out.println("Error creating the invoice.");
        }
    }

    public static void addProductsToInvoice(int invoiceId) {
        while (true) {
            try {
                System.out.println("\nAvailable Products:");
                for (int i = 0; i < ProductController.listProducts().size(); i++) {
                    System.out.println(ProductController.listProducts().get(i).getName());
                    System.out.println(ProductController.listProducts().get(i).getPrice());
                }
            } catch (SQLException ex) {
                System.out.println("Error listing products: " + ex.getMessage());
            }
            System.out.print("Enter Product ID: ");
            int productId = scanner.nextInt();
            System.out.print("Enter Quantity: ");
            int quantity = scanner.nextInt();
            scanner.nextLine();

            boolean itemResult = ProductsInvoicesControlador.insertProductsInvoice(invoiceId, productId, quantity);
            if (itemResult) {
                System.out.println("Product added to invoice.");
            } else {
                System.out.println("Error adding product to invoice.");
            }
            System.out.print("Do you want to add another product? (yes/no): ");
            String anotherProduct = scanner.nextLine();
            if (!anotherProduct.equalsIgnoreCase("yes")) {
                break;
            }
        }
    }

    public static void changeInvoiceState() {
        try {
            System.out.print("Enter Invoice ID: ");
            int invoiceId = scanner.nextInt();
            scanner.nextLine();
            Invoice invoice = InvoicesControlador.getInvoiceById(invoiceId);
            if (invoice != null) {
                System.out.print("Enter new state (true/false): ");
                boolean newState = scanner.nextBoolean();
                scanner.nextLine();
                invoice.setState(newState);
                boolean result = InvoicesControlador.updateInvoice(invoiceId, newState, invoice.getIdOwner());
                if (result) {
                    System.out.println("Invoice state changed successfully.");
                } else {
                    System.out.println("Error changing invoice state.");
                }
            } else {
                System.out.println("Invoice not found.");
            }
        } catch (Exception e) {
            System.out.println("Error changing invoice state: " + e.getMessage());
        }
    }

    public static void listPendingInvoices() {
        try {
            List<Invoice> pendingInvoices = InvoicesControlador.listInvoicesByState(false);
            if (pendingInvoices.isEmpty()) {
                System.out.println("No pending invoices found.");
            } else {
                for (Invoice invoice : pendingInvoices) {
                    System.out.println(invoice);
                }
            }
        } catch (Exception e) {
            System.out.println("Error listing pending invoices: " + e.getMessage());
        }
    }

    public static void listPaidInvoices() {
        try {
            List<Invoice> paidInvoices = InvoicesControlador.listInvoicesByState(true);
            if (paidInvoices.isEmpty()) {
                System.out.println("No paid invoices found.");
            } else {
                for (Invoice invoice : paidInvoices) {
                    System.out.println(invoice);
                }
            }
        } catch (Exception e) {
            System.out.println("Error listing paid invoices: " + e.getMessage());
        }
    }

   public static void findInvoiceById() {
    try {
        System.out.print("Enter Invoice ID to find: ");
        int invoiceId = scanner.nextInt();
        scanner.nextLine();
        Invoice invoice = InvoicesControlador.getInvoiceById(invoiceId);
        if (invoice != null) {
            System.out.println("Invoice ID: " + invoice.getCUFE());
            System.out.println("Date: " + invoice.getDateInvoice());
            System.out.println("Owner ID: " + invoice.getIdOwner());
            System.out.println("State: " + invoice.getState());
            System.out.println("Total: " + invoice.getTotal());
            
            // Mostrar productos
            System.out.println("Products:");
            
            for (ProductsInvoice productInvoice : invoice.getProductsInvoices()) {
                System.out.println("Product ID: " + productInvoice.getID_Product());
                System.out.println("Quantity: " + productInvoice.getQuantity());
                double price = ProductController.getProductId(productInvoice.getID_Product()).getPrice();
                System.out.println("Price: " + price);
                System.out.println("Subtotal: " + (price * productInvoice.getQuantity()));
            }

            // Mostrar servicios
            System.out.println("Services:");
            for (ServiceInvoice serviceInvoice : invoice.getServicesInvoices()) {
                System.out.println("Service ID: " + serviceInvoice.getIdService());
                System.out.println("Employee ID: " + serviceInvoice.getIdEmployee());
                System.out.println("Pet ID: " + serviceInvoice.getIdPet());
                System.out.println("Performance: " + serviceInvoice.getPerformance());
                System.out.println("Observations: " + serviceInvoice.getObservations());
                double servicePrice = ServiceController.getService(serviceInvoice.getIdService()).getPrice();
                System.out.println("Service Price: " + servicePrice);
            }
        } else {
            System.out.println("Invoice not found.");
        }
    } catch (Exception e) {
        System.out.println("Error finding invoice by ID: " + e.getMessage());
    }
}



    private static int getLastInvoiceId() {
        try {
            return InvoicesControlador.getLastInvoiceID();
        } catch (SQLException ex) {
            System.out.println("Error getting last invoice ID: " + ex.getMessage());
            return -1;
        }
    }

    public static void maininvoice() {
    while (true) {
        System.out.println("\n---- Invoice Management Menu ----");
        System.out.println("1. Create Invoice");
        System.out.println("2. Add Products to Existing Invoice");
        System.out.println("3. Pay Invoice");
        System.out.println("4. List Pending Invoices");
        System.out.println("5. List Paid Invoices");
        System.out.println("6. Find Invoice by ID");
        System.out.println("7. Exit");
        System.out.print("Select an option: ");
        int option = scanner.nextInt();
        scanner.nextLine();
        switch (option) {
            case 1:
                InvoiceManagement.createInvoice();
                break;
            case 2:
                addProductsToExistingInvoice();
                break;
            case 3:
                InvoiceManagement.changeInvoiceState();
                break;
            case 4:
                InvoiceManagement.listPendingInvoices();
                break;
            case 5:
                InvoiceManagement.listPaidInvoices();
                break;
            case 6:
                InvoiceManagement.findInvoiceById();
                break;
            case 7:
                System.out.println("Exiting...");
                return;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }
}

public static void addProductsToExistingInvoice() {
    System.out.print("Enter Invoice ID: ");
    int invoiceId = scanner.nextInt();
    scanner.nextLine();
    InvoiceManagement.addProductsToInvoice(invoiceId);
}


   
    
    
public static Invoice getInvoiceById(int CUFE) throws SQLException {
    String query = "SELECT i.CUFE, i.DateInvoice, i.State, i.ID_Owner, pi.ID_Product, pi.Quantity, p.Price, si.ID_Service, si.ID_Employee, si.ID_Pet, si.Performance, si.Observations, s.Price AS ServicePrice " +
                   "FROM Invoices i " +
                   "LEFT JOIN ProductsInvoices pi ON i.CUFE = pi.CUFE " +
                   "LEFT JOIN Products p ON pi.ID_Product = p.ID_Product " +
                   "LEFT JOIN ServiceInvoices si ON i.CUFE = si.CUFE " +
                   "LEFT JOIN Services s ON si.ID_Service = s.ID_Service " +
                   "WHERE i.CUFE = ?";

    Invoice invoice = null;
    double total = 0.0;

    try {
        CRUD.setConnection(ConexionDB.getConexion());
        ResultSet rs = CRUD.queryDB(query, CUFE);

        while (rs.next()) {
            if (invoice == null) {
                invoice = new Invoice(
                        rs.getInt("CUFE"),
                        rs.getInt("ID_Owner")
                );
            }

            // Obtener detalles del producto
            int productId = rs.getInt("ID_Product");
            int productQuantity = rs.getInt("Quantity");
            double productPrice = rs.getDouble("Price");

            if (productId != 0) {
                ProductsInvoice productsInvoice = new ProductsInvoice(CUFE, productId, productQuantity);
                invoice.getProductsInvoices().add(productsInvoice);

                // Calcular el total de productos
                total += productPrice * productQuantity;
            }

            // Obtener detalles del servicio
            int serviceId = rs.getInt("ID_Service");
            int employeeId = rs.getInt("ID_Employee");
            int petId = rs.getInt("ID_Pet");
            double performance = rs.getDouble("Performance");
            String observations = rs.getString("Observations");
            double servicePrice = rs.getDouble("ServicePrice");

            if (serviceId != 0) {
                ServiceInvoice serviceInvoice = new ServiceInvoice(CUFE, serviceId, employeeId, petId, performance, observations);
                invoice.getServicesInvoices().add(serviceInvoice);

                // Calcular el total de servicios
                total += servicePrice;
            }
        }
        rs.close();

        if (invoice != null) {
            invoice.setTotal(total);
        }
    } catch (SQLException e) {
        System.out.println("Error al obtener la factura: " + e.getMessage());
        CRUD.rollbackDB();
        throw e;
    } finally {
        CRUD.closeConnection();
    }

    return invoice;
}




}